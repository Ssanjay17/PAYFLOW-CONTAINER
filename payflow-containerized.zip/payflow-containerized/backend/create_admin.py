"""
PayFlow — Admin/Operator account bootstrap script.

This is intentionally a command-line-only tool, NOT an API endpoint.
There is no way to create an "admin" or "operator" account through the
public Login/Register UI or the /api/auth/* endpoints — registration
always hardcodes role="customer" (see app/routers/auth.py). This script
is the ONLY supported way to create the first admin/operator account,
and it must be run directly on the server / dev machine by someone who
already has DB access.

Usage (run from inside backend/, with your venv active):

    # Create a brand-new admin account
    python create_admin.py create --email admin@payflow.com --password "StrongPass123" --name "Ops Admin"

    # Create a brand-new operator account (same as admin, lower label only —
    # both roles pass the require_operator check in app/core/deps.py)
    python create_admin.py create --email ops@payflow.com --password "StrongPass123" --name "Ops User" --role operator

    # Promote an EXISTING customer (e.g. one who registered normally) to admin
    python create_admin.py promote --email someone@example.com --role admin

    # List current operator/admin accounts
    python create_admin.py list
"""
import argparse
import random
import string
import sys

from app.database import SessionLocal, Base, engine
from app.models.user import User, UserStatus
from app.models.account import Account
from app.core.security import hash_secret


def _generate_account_no() -> str:
    return "PF" + "".join(random.choices(string.digits, k=12))


def _generate_upi_id(mobile: str) -> str:
    return f"{mobile}@payflow"


def cmd_create(args):
    Base.metadata.create_all(bind=engine)  # safe no-op if tables already exist
    db = SessionLocal()
    try:
        if db.query(User).filter(User.email == args.email).first():
            print(f"A user with email {args.email} already exists. Use 'promote' instead.")
            sys.exit(1)

        mobile = args.mobile or ("9" + "".join(random.choices(string.digits, k=9)))
        pin = args.pin or "".join(random.choices(string.digits, k=6))

        user = User(
            name=args.name,
            email=args.email,
            mobile=mobile,
            password_hash=hash_secret(args.password),
            status=UserStatus.active,
            role=args.role,
        )
        db.add(user)
        db.flush()

        account = Account(
            user_id=user.id,
            account_no=_generate_account_no(),
            ifsc="PYFL0001234",
            bank_name="PayFlow Bank",
            balance=0,
            upi_id=_generate_upi_id(mobile),
            pin_hash=hash_secret(pin),
        )
        db.add(account)
        db.commit()

        print(f"Created {args.role} account:")
        print(f"  Email:    {args.email}")
        print(f"  Password: (as provided)")
        print(f"  Mobile:   {mobile}")
        if not args.pin:
            print(f"  Txn PIN:  {pin}  (auto-generated — note it down, it will not be shown again)")
        print("Log in at the normal Login tab — role is detected automatically and you'll be routed to admin.html.")
    finally:
        db.close()


def cmd_promote(args):
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.email == args.email).first()
        if not user:
            print(f"No user found with email {args.email}.")
            sys.exit(1)
        old_role = user.role
        user.role = args.role
        if user.status != UserStatus.active:
            user.status = UserStatus.active
        db.commit()
        print(f"Promoted {args.email} from role '{old_role}' to '{args.role}'.")
    finally:
        db.close()


def cmd_list(_args):
    db = SessionLocal()
    try:
        users = db.query(User).filter(User.role.in_(["operator", "admin"])).all()
        if not users:
            print("No operator/admin accounts exist yet.")
            return
        for u in users:
            print(f"  {u.email:30s} role={u.role:9s} status={u.status.value:12s} name={u.name}")
    finally:
        db.close()


def main():
    parser = argparse.ArgumentParser(description="Create or promote PayFlow admin/operator accounts (CLI only, never via the web UI).")
    sub = parser.add_subparsers(dest="command", required=True)

    p_create = sub.add_parser("create", help="Create a brand-new admin/operator account")
    p_create.add_argument("--email", required=True)
    p_create.add_argument("--password", required=True)
    p_create.add_argument("--name", required=True)
    p_create.add_argument("--role", choices=["admin", "operator"], default="admin")
    p_create.add_argument("--mobile", help="Optional; a random one is generated if omitted")
    p_create.add_argument("--pin", help="Optional 4-6 digit transaction PIN; a random one is generated if omitted")
    p_create.set_defaults(func=cmd_create)

    p_promote = sub.add_parser("promote", help="Promote an existing registered user to admin/operator")
    p_promote.add_argument("--email", required=True)
    p_promote.add_argument("--role", choices=["admin", "operator"], default="admin")
    p_promote.set_defaults(func=cmd_promote)

    p_list = sub.add_parser("list", help="List current admin/operator accounts")
    p_list.set_defaults(func=cmd_list)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
