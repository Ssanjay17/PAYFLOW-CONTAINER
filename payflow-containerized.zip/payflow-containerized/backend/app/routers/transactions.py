from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import or_

from app.database import get_db
from app.core.deps import get_current_user
from app.models.user import User
from app.models.transaction import Transaction
from app.schemas.payment import TransactionOut

router = APIRouter(prefix="/api/transactions", tags=["Transaction Service"])


@router.get("", response_model=list[TransactionOut])
def get_history(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    """Transaction History & Statements feature; step 6 'History & Reports' of user journey."""
    return (
        db.query(Transaction)
        .filter(or_(Transaction.sender_id == current_user.id, Transaction.receiver_id == current_user.id))
        .order_by(Transaction.created_at.desc())
        .limit(100)
        .all()
    )
