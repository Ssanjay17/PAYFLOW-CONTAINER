from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.core.deps import get_current_user
from app.models.user import User
from app.models.account import Account
from app.models.balance_request import BalanceRequest
from app.schemas.payment import PaymentRequest, PaymentResponse, BalanceRequestIn, BalanceRequestOut
from app.services.payment_service import process_payment

router = APIRouter(prefix="/api/payments", tags=["Payment Service"])


@router.post("/pay", response_model=PaymentResponse)
def make_payment(payload: PaymentRequest, db: Session = Depends(get_db),
                  current_user: User = Depends(get_current_user)):
    """
    Implements the full 8-step Request Flow (see payment_service.py docstring):
    initiate -> gateway validation -> balance check -> AI fraud check ->
    process -> update DB/cache -> notify -> return response.
    """
    sender_account = db.query(Account).filter(Account.user_id == current_user.id).first()
    if not sender_account:
        raise HTTPException(404, "Sender account not found")

    result = process_payment(
        db=db,
        sender=current_user,
        receiver_identifier=payload.receiver_identifier,
        amount=payload.amount,
        txn_type=payload.type,
        pin=payload.pin,
        pin_hash=sender_account.pin_hash,
        note=payload.note,
    )
    return result


# ---------- Add Money (self-service, admin-approved) ----------
@router.post("/balance-requests", response_model=BalanceRequestOut)
def create_balance_request(payload: BalanceRequestIn, db: Session = Depends(get_db),
                            current_user: User = Depends(get_current_user)):
    """Customer asks to add money to their own account. Nothing is credited
    yet — this just files a pending request that an operator/admin must
    approve from the Admin Panel (Balance Requests tab) before the balance
    actually changes."""
    account = db.query(Account).filter(Account.user_id == current_user.id).first()
    if not account:
        raise HTTPException(404, "You don't have a bank account on file")

    req = BalanceRequest(user_id=current_user.id, amount=payload.amount, note=payload.note)
    db.add(req)
    db.commit()
    db.refresh(req)
    return req


@router.get("/balance-requests", response_model=list[BalanceRequestOut])
def list_my_balance_requests(db: Session = Depends(get_db),
                              current_user: User = Depends(get_current_user)):
    return (
        db.query(BalanceRequest)
        .filter(BalanceRequest.user_id == current_user.id)
        .order_by(BalanceRequest.created_at.desc())
        .all()
    )