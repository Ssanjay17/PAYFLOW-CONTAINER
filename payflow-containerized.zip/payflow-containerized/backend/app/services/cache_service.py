"""
Redis cache/session layer - mirrors "Redis (Cache, Sessions)" in the Data
Layer and step 6 of the Request Flow ("cache updated in Redis").

Falls back to a harmless in-memory dict + no-op if Redis is unreachable, so
the app still runs in a bare "normal" (non-containerized) dev setup without
a Redis server running.
"""
import json
from app.config import settings

_memory_store: dict = {}
_redis_client = None
_redis_available = False

if settings.REDIS_ENABLED:
    try:
        import redis
        _redis_client = redis.from_url(settings.REDIS_URL, decode_responses=True, socket_connect_timeout=1)
        _redis_client.ping()
        _redis_available = True
    except Exception:
        _redis_available = False


def cache_set(key: str, value, ttl_seconds: int = 300):
    payload = json.dumps(value, default=str)
    if _redis_available:
        _redis_client.set(key, payload, ex=ttl_seconds)
    else:
        _memory_store[key] = payload


def cache_get(key: str):
    if _redis_available:
        raw = _redis_client.get(key)
    else:
        raw = _memory_store.get(key)
    return json.loads(raw) if raw else None


def cache_delete(key: str):
    if _redis_available:
        _redis_client.delete(key)
    else:
        _memory_store.pop(key, None)


def cache_backend_name() -> str:
    return "redis" if _redis_available else "in-memory-fallback"
