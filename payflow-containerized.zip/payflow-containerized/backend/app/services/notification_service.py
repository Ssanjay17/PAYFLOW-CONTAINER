"""
Notification Service - mirrors backend microservice "Notification Service"
and External Integration "SMS / Email Gateway". Step 7 of the Request Flow:
"Send Notification - SMS / Push / Email sent to user".

This is provider-agnostic: swap `_dispatch()` internals for Twilio/SES/FCM
etc. in production. For now it logs + persists to the notifications table,
which is enough to drive the real-time notification list in the app.
"""
from sqlalchemy.orm import Session
from app.models.notification import Notification


def _dispatch(channel: str, message: str) -> str:
    # TODO: plug real SMS/Email/Push provider here (e.g. Twilio, AWS SES, FCM)
    print(f"[NOTIFY:{channel.upper()}] {message}")
    return "sent"


def notify_user(db: Session, user_id: str, message: str, channel: str = "push") -> Notification:
    status = _dispatch(channel, message)
    note = Notification(user_id=user_id, type=channel, message=message, status=status)
    db.add(note)
    db.commit()
    db.refresh(note)
    return note
