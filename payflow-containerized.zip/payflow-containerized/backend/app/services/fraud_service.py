"""
AI Fraud Detection & Risk Scoring — client stub
================================================
The backend keeps DB access (transaction history needed to build the
feature vector) but delegates the actual model inference to the
standalone `ml-service` container over HTTP. This mirrors the
"Fraud Detection (ML Service)" box in the architecture diagram and step 4
of the Request Flow: "Fraud Check (ML Service) - Transaction risk score
evaluated by Fraud Detection Service".

Decision bands are decided by ml-service (configurable there via .env):
  risk_score >= FRAUD_BLOCK_THRESHOLD   -> block
  risk_score >= FRAUD_REVIEW_THRESHOLD  -> review (held for manual/operator check)
  else                                  -> allow
"""
from datetime import datetime, timedelta
import httpx
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.config import settings
from app.models.transaction import Transaction


class FraudDetectionService:
    """Builds the feature vector from the DB, then calls ml-service /predict."""

    def __init__(self):
        self.ml_service_url = settings.ML_SERVICE_URL.rstrip("/")

    def _build_features(self, db: Session, sender_id: str, amount: float,
                         txn_type: str, is_new_beneficiary: bool) -> dict:
        now = datetime.utcnow()
        hour_of_day = now.hour

        txn_count_last_24h = (
            db.query(func.count(Transaction.id))
            .filter(Transaction.sender_id == sender_id, Transaction.created_at >= now - timedelta(hours=24))
            .scalar() or 0
        )

        avg_amount_last_30d = (
            db.query(func.avg(Transaction.amount))
            .filter(Transaction.sender_id == sender_id, Transaction.created_at >= now - timedelta(days=30))
            .scalar()
        )
        avg_amount_last_30d = float(avg_amount_last_30d) if avg_amount_last_30d else max(amount, 1.0)

        amount_to_avg_ratio = amount / max(avg_amount_last_30d, 1.0)
        is_high_risk_type = 1 if txn_type in ("wallet", "qr_payment") else 0

        return {
            "amount": amount,
            "hour_of_day": hour_of_day,
            "is_new_beneficiary": int(is_new_beneficiary),
            "txn_count_last_24h": txn_count_last_24h,
            "avg_amount_last_30d": avg_amount_last_30d,
            "amount_to_avg_ratio": amount_to_avg_ratio,
            "is_high_risk_type": is_high_risk_type,
        }

    def score_transaction(self, db: Session, sender_id: str, amount: float,
                           txn_type: str, is_new_beneficiary: bool = False) -> dict:
        features = self._build_features(db, sender_id, amount, txn_type, is_new_beneficiary)
        try:
            resp = httpx.post(f"{self.ml_service_url}/predict", json=features, timeout=5.0)
            resp.raise_for_status()
            return resp.json()
        except httpx.HTTPError as exc:
            # Fail safe: if the AI/ML container is unreachable, don't silently
            # let payments through un-checked — flag for manual review instead.
            return {
                "risk_score": 0.5,
                "status": "review",
                "reason": f"AI/ML fraud service unreachable ({exc.__class__.__name__}); flagged for manual review",
            }


fraud_service = FraudDetectionService()
