"""
PayFlow - Digital Banking & Payments Platform
Backend / Core API container. Owns auth, accounts, payments, transactions,
beneficiaries, notifications, KYC and admin — everything except AI/ML
inference, which lives in the separate `ml-service` container, and the UI,
which lives in the `frontend-*` containers behind the `gateway`.

Containerized run: see /docker-compose.yml at the project root.

Standalone (non-container) dev run:
    cd backend
    cp .env.example .env      # edit MYSQL_URL / ML_SERVICE_URL
    pip install -r requirements.txt --break-system-packages
    uvicorn app.main:app --reload --port 8000

Docs: http://localhost:8000/docs
"""
import time
from collections import defaultdict
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.database import Base, engine
from app import models  # noqa: ensures all models are registered with Base
from app.config import settings

from app.routers import auth, users, accounts, beneficiaries, payments, transactions, notifications, kyc, admin

app = FastAPI(
    title="PayFlow API",
    description="Secure • Fast • Intelligent • Scalable — Digital Banking & Payments Platform",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---- Simple in-process rate limiting (API Gateway responsibility) ----
_request_log: dict[str, list[float]] = defaultdict(list)
RATE_LIMIT = 120          # requests
RATE_WINDOW_SECONDS = 60  # per minute


@app.middleware("http")
async def rate_limiter(request: Request, call_next):
    client_ip = request.client.host if request.client else "unknown"
    now = time.time()
    window_start = now - RATE_WINDOW_SECONDS
    _request_log[client_ip] = [t for t in _request_log[client_ip] if t > window_start]

    if len(_request_log[client_ip]) >= RATE_LIMIT:
        return JSONResponse(status_code=429, content={"detail": "Rate limit exceeded. Try again shortly."})

    _request_log[client_ip].append(now)
    return await call_next(request)


@app.on_event("startup")
def on_startup():
    # Wait for MySQL to actually be ready to accept connections before
    # creating tables. On first boot the `db` container can take well over
    # the depends_on/healthcheck window to finish initializing its data
    # directory, and podman-compose's healthcheck-gating isn't always as
    # strict as docker-compose's — so retry here instead of crashing.
    import time as _time
    from sqlalchemy.exc import OperationalError

    max_attempts = 30
    delay_seconds = 2
    for attempt in range(1, max_attempts + 1):
        try:
            with engine.connect():
                pass
            break
        except OperationalError:
            if attempt == max_attempts:
                raise
            print(f"[startup] MySQL not ready yet (attempt {attempt}/{max_attempts}), retrying in {delay_seconds}s...")
            _time.sleep(delay_seconds)

    # Creates tables if they don't exist (MySQL).
    Base.metadata.create_all(bind=engine)


@app.get("/", tags=["Health"])
def root():
    return {
        "service": "PayFlow API Gateway",
        "status": "healthy",
        "db_engine": "mysql",
        "features": [
            "UPI Payments", "Bill Payments", "Bank Transfer", "Recharge", "Wallet", "QR Payments",
            "AI Fraud Detection", "Real-time Notifications", "Operator/Admin Panel",
        ],
    }


@app.get("/health", tags=["Health"])
def health():
    return {"status": "ok"}


# ---- Route requests to backend microservice routers (API Gateway pattern) ----
app.include_router(auth.router)
app.include_router(users.router)
app.include_router(accounts.router)
app.include_router(beneficiaries.router)
app.include_router(payments.router)
app.include_router(transactions.router)
app.include_router(notifications.router)
app.include_router(kyc.router)
app.include_router(admin.router)

# ---- Frontend is no longer served from here ----
# In the containerized architecture, the UI ships as three separate
# micro-frontend containers (frontend-index, frontend-dashboard,
# frontend-admin) sitting behind the `gateway` nginx container, which is
# the single entry point for browsers. This container is API-only.
