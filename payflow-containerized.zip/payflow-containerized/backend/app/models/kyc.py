import uuid
from datetime import datetime
from sqlalchemy import Column, String, DateTime, ForeignKey
from app.database import Base


class KycDetail(Base):
    __tablename__ = "kyc_details"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    kyc_type = Column(String(30), nullable=False)  # aadhaar | pan | passport
    doc_url = Column(String(255), nullable=False)
    status = Column(String(20), default="pending")  # pending | verified | rejected
    verified_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
