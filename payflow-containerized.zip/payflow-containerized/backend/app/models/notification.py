import uuid
from datetime import datetime
from sqlalchemy import Column, String, DateTime, ForeignKey
from app.database import Base


class Notification(Base):
    __tablename__ = "notifications"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    type = Column(String(20), default="push")  # sms | email | push
    message = Column(String(255), nullable=False)
    status = Column(String(20), default="sent")  # sent | failed | pending
    created_at = Column(DateTime, default=datetime.utcnow)
