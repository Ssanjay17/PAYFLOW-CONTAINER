import uuid
from datetime import datetime
from sqlalchemy import Column, String, DateTime, Numeric, ForeignKey, Enum
import enum
from app.database import Base


class TxnType(str, enum.Enum):
    upi = "upi"
    bank_transfer = "bank_transfer"
    bill_payment = "bill_payment"
    recharge = "recharge"
    wallet = "wallet"
    qr_payment = "qr_payment"


class TxnStatus(str, enum.Enum):
    initiated = "initiated"
    success = "success"
    failed = "failed"
    blocked_fraud = "blocked_fraud"
    under_review = "under_review"


class Transaction(Base):
    __tablename__ = "transactions"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    sender_id = Column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    receiver_id = Column(String(36), ForeignKey("users.id"), nullable=True, index=True)
    amount = Column(Numeric(14, 2), nullable=False)
    type = Column(Enum(TxnType), nullable=False)
    status = Column(Enum(TxnStatus), default=TxnStatus.initiated)
    txn_ref_no = Column(String(40), unique=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
