"""
PayFlow configuration.

MySQL-only build: the DB layer talks to MySQL via PyMySQL.
"""
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    APP_NAME: str = "PayFlow"
    ENV: str = "development"

    # Database (MySQL only)
    MYSQL_URL: str = "mysql+pymysql://payflow_user:payflow_pass@localhost:3306/payflow_db"

    # Redis
    REDIS_URL: str = "redis://localhost:6379/0"
    REDIS_ENABLED: bool = True

    # AI/ML fraud detection microservice (separate container)
    ML_SERVICE_URL: str = "http://ml-service:8100"

    # Security
    JWT_SECRET_KEY: str = "change_this_to_a_long_random_secret"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60

    # Fraud / business rules
    FRAUD_BLOCK_THRESHOLD: float = 0.80
    FRAUD_REVIEW_THRESHOLD: float = 0.50
    DAILY_TRANSFER_LIMIT: float = 200000

    @property
    def DATABASE_URL(self) -> str:
        return self.MYSQL_URL

    class Config:
        env_file = ".env"


settings = Settings()
