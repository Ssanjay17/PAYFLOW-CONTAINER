// Containerized deployment: the browser only ever talks to the `gateway`
// container (single exposed entry point), which reverse-proxies /api/* to
// the backend-api container. No cross-origin calls needed between the
// UI containers and the backend container.
window.PAYFLOW_API_BASE = window.location.origin;
