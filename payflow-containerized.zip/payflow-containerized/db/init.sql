-- Runs automatically on first container start (mounted into
-- /docker-entrypoint-initdb.d/ by docker-compose.yml).
-- The database + user themselves are already created via the
-- MYSQL_DATABASE / MYSQL_USER / MYSQL_PASSWORD env vars on the `db`
-- service — this file is a hook for any future seed data / extra grants.

ALTER USER 'payflow_user'@'%' IDENTIFIED WITH mysql_native_password BY 'payflow_pass';
FLUSH PRIVILEGES;
