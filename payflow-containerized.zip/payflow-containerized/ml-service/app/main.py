"""
PayFlow AI/ML Service — Fraud Detection & Risk Scoring (standalone container)
==============================================================================
Extracted from the monolithic backend into its own microservice. Owns the
RandomForest + IsolationForest models and does pure inference on a feature
vector handed to it over HTTP by the backend (which owns the DB queries
needed to build that feature vector).

Endpoints:
    GET  /health        -> liveness/readiness probe
    POST /predict        -> {risk_score, status, reason}
"""
import os
import subprocess
import numpy as np
import joblib
from fastapi import FastAPI
from pydantic import BaseModel

MODEL_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models")
FRAUD_BLOCK_THRESHOLD = float(os.getenv("FRAUD_BLOCK_THRESHOLD", "0.80"))
FRAUD_REVIEW_THRESHOLD = float(os.getenv("FRAUD_REVIEW_THRESHOLD", "0.50"))

app = FastAPI(
    title="PayFlow AI/ML Service",
    description="Fraud Detection & Risk Scoring microservice",
    version="1.0.0",
)


class PredictRequest(BaseModel):
    amount: float
    hour_of_day: int
    is_new_beneficiary: int
    txn_count_last_24h: int
    avg_amount_last_30d: float
    amount_to_avg_ratio: float
    is_high_risk_type: int


class PredictResponse(BaseModel):
    risk_score: float
    status: str
    reason: str


class FraudModel:
    def __init__(self):
        self.clf = None
        self.iso = None
        self.scaler = None
        self.feature_cols = None
        self._load()

    def _load(self):
        required = [
            "fraud_rf_model.pkl", "fraud_isolation_model.pkl",
            "fraud_scaler.pkl", "fraud_feature_cols.pkl",
        ]
        if not all(os.path.exists(os.path.join(MODEL_DIR, f)) for f in required):
            # First boot / no pre-trained model baked into the image: train now.
            os.makedirs(MODEL_DIR, exist_ok=True)
            subprocess.run(
                ["python", os.path.join(os.path.dirname(os.path.abspath(__file__)), "train_fraud_model.py")],
                check=True, cwd=MODEL_DIR,
            )
        self.clf = joblib.load(os.path.join(MODEL_DIR, "fraud_rf_model.pkl"))
        self.iso = joblib.load(os.path.join(MODEL_DIR, "fraud_isolation_model.pkl"))
        self.scaler = joblib.load(os.path.join(MODEL_DIR, "fraud_scaler.pkl"))
        self.feature_cols = joblib.load(os.path.join(MODEL_DIR, "fraud_feature_cols.pkl"))

    def score(self, req: PredictRequest) -> dict:
        row = req.model_dump()
        X = np.array([[row[c] for c in self.feature_cols]])
        X_scaled = self.scaler.transform(X)

        fraud_prob = float(self.clf.predict_proba(X_scaled)[0][1])
        anomaly_raw = float(self.iso.decision_function(X_scaled)[0])
        anomaly_score = float(np.clip(0.5 - anomaly_raw, 0, 1))
        risk_score = round(0.7 * fraud_prob + 0.3 * anomaly_score, 4)

        if risk_score >= FRAUD_BLOCK_THRESHOLD:
            status, reason = "block", "High-confidence fraud pattern detected by AI risk model"
        elif risk_score >= FRAUD_REVIEW_THRESHOLD:
            status, reason = "review", "Elevated risk score - flagged for manual/operator review"
        else:
            status, reason = "allow", "Transaction within normal risk profile"

        return {"risk_score": risk_score, "status": status, "reason": reason}


model = FraudModel()


@app.get("/health", tags=["Health"])
def health():
    return {"status": "ok", "service": "ml-service", "models_loaded": model.clf is not None}


@app.post("/predict", response_model=PredictResponse, tags=["Fraud AI/ML"])
def predict(req: PredictRequest):
    return model.score(req)
