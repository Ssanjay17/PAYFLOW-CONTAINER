requireAuth();
const user = getUser();
document.getElementById('sideName').textContent = user?.name || '—';
document.getElementById('topName').textContent = (user?.name || '').split(' ')[0] || '';
document.getElementById('avatarInit').textContent = initials(user?.name);

let currentTxnType = 'upi';

function logout() { clearSession(); window.location.href = 'index.html'; }

function scrollToHistory() {
  document.getElementById('historyCard').scrollIntoView({ behavior: 'smooth' });
}

async function loadAccount() {
  try {
    const acc = await api('/api/accounts/me');
    document.getElementById('balanceVal').textContent = money(acc.balance);
    document.getElementById('accMeta').textContent = `${acc.bank_name} · A/C ${acc.account_no}`;
    document.getElementById('upiVal').textContent = acc.upi_id || '—';
  } catch (e) { showToast(e.message, true); }

  try {
    const me = await api('/api/users/me');
    const badge = document.getElementById('statusBadge');
    badge.textContent = me.status;
    badge.className = 'badge ' + me.status;
    document.getElementById('statusHint').textContent =
      me.status === 'active' ? 'Full features unlocked' :
      me.status === 'pending_kyc' ? 'Complete KYC to unlock full limits' : 'Contact support';
  } catch (e) { /* ignore */ }
}

async function loadHistory() {
  const body = document.getElementById('historyBody');
  try {
    const txns = await api('/api/transactions');
    if (!txns.length) {
      body.innerHTML = `<tr><td colspan="5" class="empty-state">No transactions yet. Send your first payment!</td></tr>`;
      return;
    }
    body.innerHTML = txns.map(t => `
      <tr>
        <td>${t.txn_ref_no}</td>
        <td>${t.type.replace('_',' ')}</td>
        <td>${money(t.amount)}</td>
        <td><span class="badge ${t.status}">${t.status.replace('_',' ')}</span></td>
        <td>${timeAgo(t.created_at)}</td>
      </tr>`).join('');
  } catch (e) {
    body.innerHTML = `<tr><td colspan="5" class="empty-state">Couldn't load history</td></tr>`;
  }
}

async function loadNotifications() {
  const el = document.getElementById('notifList');
  try {
    const notes = await api('/api/notifications');
    if (!notes.length) {
      el.innerHTML = `<div class="empty-state">No notifications yet</div>`;
      return;
    }
    el.innerHTML = notes.slice(0, 8).map(n => `
      <div style="display:flex;gap:10px;align-items:flex-start;">
        <div style="font-size:16px;">${n.type === 'sms' ? '💬' : n.type === 'email' ? '📧' : '🔔'}</div>
        <div>
          <div style="font-size:13px;">${n.message}</div>
          <div style="font-size:11px;color:var(--text-dim);">${timeAgo(n.created_at)}</div>
        </div>
      </div>`).join('');
  } catch (e) {
    el.innerHTML = `<div class="empty-state">Couldn't load notifications</div>`;
  }
}

// ---- Send Money / Verify & Pay flow ----
function openSend(type) {
  currentTxnType = type;
  const titles = {
    upi: 'Send Money (UPI)', bill_payment: 'Bill Payment', bank_transfer: 'Bank Transfer',
    recharge: 'Mobile Recharge', wallet: 'Wallet Payment', qr_payment: 'QR Payment',
  };
  document.getElementById('sendTitle').textContent = titles[type] || 'Send Money';
  document.getElementById('sendStep1').style.display = 'block';
  document.getElementById('sendStep2').style.display = 'none';
  document.getElementById('sendStep3').style.display = 'none';
  document.getElementById('sendError').style.display = 'none';
  document.getElementById('receiverId').value = '';
  document.getElementById('amount').value = '';
  document.getElementById('note').value = '';
  document.getElementById('pin').value = '';
  document.getElementById('sendModal').classList.add('open');
}

function closeModal(id) { document.getElementById(id).classList.remove('open'); }

function goToVerify() {
  const receiver = document.getElementById('receiverId').value.trim();
  const amount = parseFloat(document.getElementById('amount').value);
  const errEl = document.getElementById('sendError');
  errEl.style.display = 'none';
  if (!receiver || !amount || amount <= 0) {
    errEl.textContent = 'Enter a valid receiver and amount'; errEl.style.display = 'block'; return;
  }
  document.getElementById('sendStep1').style.display = 'none';
  document.getElementById('sendStep2').style.display = 'block';
}

function backToStep1() {
  document.getElementById('sendStep2').style.display = 'none';
  document.getElementById('sendStep1').style.display = 'block';
}

async function submitPayment() {
  const pin = document.getElementById('pin').value;
  const errEl = document.getElementById('sendError');
  errEl.style.display = 'none';
  if (!pin) { errEl.textContent = 'Enter your transaction PIN'; errEl.style.display = 'block'; return; }

  const payBtn = document.getElementById('payBtn');
  payBtn.disabled = true; payBtn.textContent = 'Processing…';

  try {
    const result = await api('/api/payments/pay', {
      method: 'POST',
      body: {
        receiver_identifier: document.getElementById('receiverId').value.trim(),
        amount: parseFloat(document.getElementById('amount').value),
        type: currentTxnType,
        pin,
        note: document.getElementById('note').value.trim() || null,
      },
    });
    showResult(result);
  } catch (e) {
    errEl.textContent = e.message; errEl.style.display = 'block';
  } finally {
    payBtn.disabled = false; payBtn.textContent = 'Confirm & Pay';
  }
}

function showResult(result) {
  document.getElementById('sendStep2').style.display = 'none';
  document.getElementById('sendStep3').style.display = 'block';

  const icon = document.getElementById('resultIcon');
  const title = document.getElementById('resultTitle');
  const msg = document.getElementById('resultMsg');
  const riskFill = document.getElementById('riskFill');
  const riskLabel = document.getElementById('riskLabel');

  const riskPct = Math.round(result.risk_score * 100);
  riskFill.style.width = riskPct + '%';
  riskFill.style.background = riskPct >= 80 ? 'var(--red)' : riskPct >= 50 ? 'var(--orange)' : 'var(--teal)';
  riskLabel.textContent = `${riskPct}% risk · ${result.status.replace('_', ' ')}`;

  if (result.status === 'success') {
    icon.textContent = '✅'; title.textContent = 'Payment Successful';
  } else if (result.status === 'under_review') {
    icon.textContent = '⏳'; title.textContent = 'Under Review';
  } else if (result.status === 'blocked_fraud') {
    icon.textContent = '🚫'; title.textContent = 'Transaction Blocked';
  } else {
    icon.textContent = 'ℹ️'; title.textContent = 'Transaction Update';
  }
  msg.textContent = `${result.message} · Ref: ${result.txn_ref_no}`;
}

function finishFlow() {
  closeModal('sendModal');
  loadAccount(); loadHistory(); loadNotifications();
  showToast('Dashboard updated');
}

// ---- Add Money (self-service, admin-approved) ----
function openAddMoney() {
  document.getElementById('addMoneyError').style.display = 'none';
  document.getElementById('addMoneyAmount').value = '';
  document.getElementById('addMoneyNote').value = '';
  document.getElementById('addMoneyModal').classList.add('open');
}

async function submitAddMoney() {
  const amount = parseFloat(document.getElementById('addMoneyAmount').value);
  const note = document.getElementById('addMoneyNote').value.trim() || null;
  const errEl = document.getElementById('addMoneyError');
  errEl.style.display = 'none';
  if (!amount || amount <= 0) {
    errEl.textContent = 'Enter a valid amount'; errEl.style.display = 'block'; return;
  }

  const btn = document.getElementById('addMoneyBtn');
  btn.disabled = true; btn.textContent = 'Submitting…';
  try {
    await api('/api/payments/balance-requests', { method: 'POST', body: { amount, note } });
    closeModal('addMoneyModal');
    showToast('Add Money request submitted — awaiting approval');
    loadBalanceRequests();
  } catch (e) {
    errEl.textContent = e.message; errEl.style.display = 'block';
  } finally {
    btn.disabled = false; btn.textContent = 'Submit Request';
  }
}

async function loadBalanceRequests() {
  const body = document.getElementById('balanceReqBody');
  try {
    const reqs = await api('/api/payments/balance-requests');
    if (!reqs.length) {
      body.innerHTML = `<tr><td colspan="5" class="empty-state">No Add Money requests yet</td></tr>`;
      return;
    }
    const statusBadge = { pending: 'pending', approved: 'success', rejected: 'failed' };
    body.innerHTML = reqs.map(r => `
      <tr>
        <td>${money(r.amount)}</td>
        <td>${r.note || '—'}</td>
        <td><span class="badge ${statusBadge[r.status] || 'pending'}">${r.status}</span></td>
        <td>${r.remarks || '—'}</td>
        <td>${timeAgo(r.created_at)}</td>
      </tr>`).join('');
  } catch (e) {
    body.innerHTML = `<tr><td colspan="5" class="empty-state">Couldn't load requests</td></tr>`;
  }
}

// ---- KYC ----
function openKyc() { document.getElementById('kycModal').classList.add('open'); }
async function submitKyc() {
  try {
    await api('/api/kyc/submit', {
      method: 'POST',
      body: { kyc_type: document.getElementById('kycType').value, doc_url: document.getElementById('kycDoc').value || 'uploaded-doc' },
    });
    closeModal('kycModal');
    showToast('KYC submitted for verification');
    loadAccount();
  } catch (e) { showToast(e.message, true); }
}

loadAccount();
loadHistory();
loadNotifications();
loadBalanceRequests();
